﻿namespace JustSport.Controllers
{
    internal class ErrorViewModel
    {
        public string RequestId { get; set; }
    }
}