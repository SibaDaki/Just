﻿using JustSport.DataAccessLayer;
using JustSport.Entity;
using JustSport.Models;

using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JustSport.Controllers
{
    public class MemberController : Controller
    {

        private readonly IRepository _repository;
        private readonly JustDbContext _context;

        public MemberController(IRepository repository, JustDbContext context)
        {
            _repository = repository;
            _context = context;
        }
        // GET: MemberController
        public async Task<ActionResult> Index()
        {
            return View(await _repository.GetAllAsync());
        }


        // GET: MemberController/Create
        public ActionResult AddMember()
        {
            loadDDL();
            return View();
        }

        // POST: MemberController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> AddMember(Member member)
        {
            try 
            {
                if (ModelState.IsValid)
                {
                    await _repository.CreateAsync(member);
                    return RedirectToAction("Index");
                }
                return RedirectToAction("Index");
            }
            catch
            {
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");

            }
            return View(member);
        }

       private void loadDDL()
       {
            try
            {
                List<SportChoice> sportList = new List<SportChoice>();
                sportList = _context.Sports.ToList();
                sportList.Insert(0, new SportChoice { Id = 0, Sport = "--Please Select--" });

                ViewBag.SportList = sportList;

            }
            catch(Exception ex)
            {

            }
       }
    }
}
