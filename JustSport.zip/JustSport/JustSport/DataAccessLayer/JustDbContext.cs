﻿using JustSport.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JustSport.DataAccessLayer
{
    public class JustDbContext : DbContext
    {
        public  JustDbContext(DbContextOptions<JustDbContext> options ) : base (options)
        {

        }
        public DbSet<Member> Members { get; set; }
        public DbSet<SportChoice> Sports { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Member>().ToTable("Members");
            modelBuilder.Entity<SportChoice>().ToTable("Sports");
        }
          
    }
}
