﻿using JustSport.Entity;
using JustSport.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JustSport.DataAccessLayer
{
    public class CreateModel : PageModel
    {
        private readonly IRepository _repository;
        [BindProperty]
        public Member member { get; set; }

        public CreateModel(IRepository repository)
        {
            _repository = repository;
        }

        public IActionResult onGet()
        {
            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (ModelState.IsValid)
                await _repository.CreateAsync(member);
            return Page();

        }
       
    }
}
