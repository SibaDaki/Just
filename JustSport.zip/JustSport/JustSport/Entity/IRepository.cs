﻿using JustSport.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JustSport.Entity
{
    public interface IRepository
    {
        Task CreateAsync(Member member);
        Task <List<Member>> GetAllAsync();

    }
}
