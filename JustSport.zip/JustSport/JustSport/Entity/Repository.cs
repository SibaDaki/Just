﻿using JustSport.DataAccessLayer;
using JustSport.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JustSport.Entity
{
    public class Repository : IRepository
    {

        private readonly JustDbContext _context;

        public Repository(JustDbContext context)
        {
            _context = context;
        }
        public async Task CreateAsync(Member member)
        {
            _context.Members.Add(member);
            await _context.SaveChangesAsync();

        }

        public async Task<List<Member>> GetAllAsync()
        {
            return await (from a in _context.Members
                          join b in _context.Sports
                          on a.SportId equals b.Id
                          into spt
                          from b in spt.DefaultIfEmpty()

                          select new Member
                          {
                              Id = a.Id,
                              Firstname = a.Firstname,
                              Surname = a.Surname,
                              Email = a.Email,
                              Sport = b == null ? "" : b.Sport

                          }).ToListAsync();


            // await _dbContext.Members.ToListAsync();
        }
    }
}
